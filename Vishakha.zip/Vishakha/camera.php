<?php
require("includes/common.php");

if (isset($_SESSION['email'])) {
    header('location: products.php');
}
?>

<!DOCTYPE html>
<!--

-->
<html>
    <head>
        <title>E-Store</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css.css" type="text/css">

    </head>
    <body style="background-color:black;">
        <?php
        include 'includes/header.php';
        ?>
<div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Camera</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/camera4.jpeg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.40,000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Camera</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/camera3.jpeg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.50,000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Camera</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/camera2.jpeg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.45,000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Camera</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/camera1.jpeg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.60,000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
            </body>
            </html>




