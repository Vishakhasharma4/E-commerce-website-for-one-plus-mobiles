<?php
require("includes/common.php");

if (isset($_SESSION['email'])) {
    header('location: products.php');
}
?>

<!DOCTYPE html>
<!--

-->
<html>
    <head>
        <title>E-Store</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css.css" type="text/css">

    </head>
    <body style="background-color:black;">
        <?php
        include 'includes/header.php'
        ?>
<div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Sweets</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="food2.php">
                                <img alt="sweets" src="img/sweet4.jpeg">
                            </a>
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Click on the picture</button>
                            </div>
                        </div> 
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
                            <h4>Chocolates</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="food3.php">
                                <img alt="chocolate" src="img/choclate1.jpeg">
                            </a>
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Click on the picture</button>
                            </div>
                        </div>
                        
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Noodles</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="food4.php">
                                <img alt="noodles" src="img/noodle1.jpeg"
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Click on the picture</button>
                            </div>
                        </div>
                        
                    </div>	
                </div>


