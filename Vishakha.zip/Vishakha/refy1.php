<?php
require("includes/common.php");

if (isset($_SESSION['email'])) {
    header('location: products.php');
}
?>

<!DOCTYPE html>
<!--

-->
<html>
    <head>
        <title>E-Store</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css.css" type="text/css">

    </head>
    <body style="background-color:black;">
        <?php
        include 'includes/header.php';
        ?>
<div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref2.jpg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.11500</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref3.jpg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.14000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref4.jpg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.12100</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref5.jpg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.11400</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref1.jpg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.16000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref6.jpg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.16000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                 <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref7.jpg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.16000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>

                 <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref8.jpg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.16000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>

                 <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref9.webp">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.16000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>

                 <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Refrigerator</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/ref5.jpg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.16000</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>

            </body>
            </html>





