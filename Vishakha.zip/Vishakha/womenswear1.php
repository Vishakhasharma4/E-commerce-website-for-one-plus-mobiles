<?php
require("includes/common.php");

if (isset($_SESSION['email'])) {
    header('location: products.php');
}
?>

<!DOCTYPE html>
<!--

-->
<html>
    <head>
        <title>E-Store</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css.css" type="text/css">

    </head>
    <body style="background-color:powderblue;">
        <?php
        include 'includes/header.php';
        ?>
<div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Tops</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="womenswear2.php">
                                <img alt="Tops" src="img/top1.jpeg"
                            </a>
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Click on the picture</button>
                            </div>
                        </div> 
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
                            <h4>kurtis</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="women3.php">
                                <img alt="kurtis" src="img/kurti1.jpeg">
                            </a>
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Click on the picture</button>
                            </div>
                        </div>
                        
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Footwears</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="women4.php">
                                <img alt="mobile" src="img/footwear1.jpeg">
                            </a>
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Click on the picture</button>
                            </div>
                        </div>
                        
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Hoddies</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="hood.php">
                                <img alt="mobile" src="img/hoodies5.jpeg">
                            </a>
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Click on the picture</button>
                            </div>
                        </div>
                    
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Pants</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="pants.php">
                                <img alt="mobile" src="img/pants4.jpeg">
                            </a>
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Click on the picture</button>
                            </div>
                        </div>
                        
                    	
                </div>
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Suits</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="suits.php">
                                <img alt="suit" src="img/suit1.jpeg">
                            </a>
                            
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Click on the picture</button>
                            </div>
                        </div>
                    </div>
                    </div>	
                </div>


