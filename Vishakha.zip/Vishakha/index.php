<?php
require("includes/common.php");

if (isset($_SESSION['email'])) {
    header('location: products.php');
}
?>

<!DOCTYPE html>
<!--

-->
<html>
    <head>
        <title>E-Store</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css.css" type="text/css">

    </head>
    <body style="background-color:black;">
        
        <?php
        include 'includes/header.php';
        ?>
       
        
        <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Electronics</h4>
			</div>
					
			<div class="thumbnail">
                            <a href="electronic.php">
                                <img alt="Electronics" src="img/image1.jpg">
                            </a>
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                        
                    </div>	
                </div>

                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
                            <h4>Gadgets</h4>
								</div>
							
								<div class="thumbnail">
                                                                    <a href="gadget1.php">
                                                                        <img alt="Gadgets" src="img/image2.jpg">
                                                                    </a>
                                    
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>

                         <div class="col-sm-4">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4>Men's wear</h4>
								</div>
							
							<div class="thumbnail">
                                                            <a href="menswear1.php">
                                                            
                                    <img src="img/image3.jpg">
                                                            </a>
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>
                    </div>
				</div>
					
				<div class="container-fluid">
					<div class="row">
                        <div class="col-sm-4">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4>Makeup products</h4>
								</div>
							
								<div class="thumbnail">
                                                                    <a href="makeup1.php">
                                                                        <img alt="Food" src="img/mk0.jpg">
                                                                    </a>
                                    
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>

                        <div class="col-sm-4">
							<div class="panel panel-default">
								<div class="panel-heading">
                                                                    <h4>Food items</h4>
								</div>
							
								<div class="thumbnail">
                                   <a href="food1.php">
                                       <img alt="Food" src="img/image4.jpg">
                                                                    </a>
                                                                    
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>

                        <div class="col-sm-4">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4>women's Fashion</h4>
								</div>
							
								<div class="thumbnail">
                                                                    <a href="womenswear1.php">                                
                                    <img src="img/image6.jpg">
                                                                    </a>
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>
						
                    </div>
				</div>
                
        
        
        <?php
        include 'includes/footer.php';
        ?>
    </body>
</html>
