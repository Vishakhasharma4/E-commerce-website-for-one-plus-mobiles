<?php
require("includes/common.php");

if (isset($_SESSION['email'])) {
    header('location: products.php');
}
?>

<!DOCTYPE html>
<!--

-->
<html>
    <head>
        <title>Electronics</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css.css" type="text/css">

    </head>
    <body>
        <?php
        include 'includes/header.php';
        ?>
        
        <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Electronics</h4>
			</div>
					
			<div class="thumbnail">
                            <img src="img/image11.jpg">
                            <div class="caption">
				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                        
                    </div>	
                </div>

                <div class="col-sm-4">
                    <div class="panel panel-default">
			<div class="panel-heading">
                            <h4>Gadgets</h4>
								</div>
							
								<div class="thumbnail">
                                    <img src="img/image22.jpg">
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>

                         <div class="col-sm-4">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4>Men's wear</h4>
								</div>
							
							<div class="thumbnail">
                                    <img src="img/image33.jpg">
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>
                    </div>
				</div>
					
				<div class="container-fluid">
					<div class="row">
                        <div class="col-sm-4">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4>Food Items</h4>
								</div>
							
								<div class="thumbnail">
                                    <img src="img/image44.jpg">
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>

                        <div class="col-sm-4">
							<div class="panel panel-default">
								<div class="panel-heading">
                                                                    <h4>Makeup Products</h4>
								</div>
							
								<div class="thumbnail">
                                    <img src="img/image55.jpg">
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>

                        <div class="col-sm-4">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4>women's Fashion</h4>
								</div>
							
								<div class="thumbnail">
                                    <img src="img/image66.jpg">
                                        <div class="caption">
											
											<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                                        </div>
                                </div>
                        
							</div>	
                        </div>
						
                    </div>
				</div>
                
        
        
        <?php
        include 'includes/footer.php';
        ?>
        <a href="electronics.php"></a>
    </body>
</html>


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

