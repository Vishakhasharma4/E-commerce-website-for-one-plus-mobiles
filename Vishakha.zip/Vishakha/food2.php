<?php
require("includes/common.php");

if (isset($_SESSION['email'])) {
    header('location: products.php');
}
?>

<!DOCTYPE html>
<!--

-->
<html>
    <head>
        <title>E-Store</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="css/css.css" type="text/css">

    </head>
    <body style="background-color:black;">
        <?php
        include 'includes/header.php';
        ?>
<div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>Sweets</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/sweet2.jpeg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.500</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>sweets</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/sweet3.jpeg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.400</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>sweets</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/sweet1.jpeg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.1100</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>sweets</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/sweet4.jpeg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.400</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="container-fluid"><br><br><br><br>
            <div class="row">
                <div class="col-sm-12">
                    <div class="panel panel-default">
			<div class="panel-heading">
			<h4>sweets</h4>
 
			</div>
					
			<div class="thumbnail">
                            
                            <img src="img/sweet5.jpeg">
                            <div class="caption">
                                                                                                <p style="text-align:center;">Rs.600</p>

				<button class="btn btn-block btn-primary" data-toggle="modal" data-target="#loginmodal">Order Now!</button>
                            </div>
                        </div>
                    </div>	
                </div>
            </body>
            </html>





