<?php
$con=mysqli_connect("localhost","root","","ecommerce","3308")
or die(mysql_error($con));
if(!isset($_SESSION)){
    session_start();
}
?>

